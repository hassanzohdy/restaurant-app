export { default } from "./PostContent";
