export default function PostSidebar() {
  return (
    <>
      <h1>PostSidebar</h1>
    </>
  );
}
