export { default } from "./PostDetailsPage";
