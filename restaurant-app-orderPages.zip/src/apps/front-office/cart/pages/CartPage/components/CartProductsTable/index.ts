export { default } from "./CartProductsTable";
