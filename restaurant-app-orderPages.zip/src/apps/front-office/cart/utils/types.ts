// types.ts file
