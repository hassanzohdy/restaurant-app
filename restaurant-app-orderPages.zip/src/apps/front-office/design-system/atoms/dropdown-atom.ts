import { openAtom } from "@mongez/react-atom";

export const dropdownAtom = openAtom("dropdown");
