export { default } from "./CommonTitle";
