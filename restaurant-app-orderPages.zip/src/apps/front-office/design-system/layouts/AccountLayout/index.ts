export { default } from "./AccountLayout";
