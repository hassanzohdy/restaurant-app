export { default } from "./FooterCopyRights";
