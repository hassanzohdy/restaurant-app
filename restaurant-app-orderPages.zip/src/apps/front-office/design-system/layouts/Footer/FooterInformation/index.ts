export { default } from "./FooterInformation";
