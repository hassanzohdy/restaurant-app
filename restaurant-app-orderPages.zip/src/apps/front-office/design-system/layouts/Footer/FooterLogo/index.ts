export { default } from "./FooterLogo";
