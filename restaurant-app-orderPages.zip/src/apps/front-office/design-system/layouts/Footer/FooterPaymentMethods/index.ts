export { default } from "./FooterPaymentMethods";
