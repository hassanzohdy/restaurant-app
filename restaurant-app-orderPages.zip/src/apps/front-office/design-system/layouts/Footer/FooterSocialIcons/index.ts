export { default } from "./FooterSocialIcons";
