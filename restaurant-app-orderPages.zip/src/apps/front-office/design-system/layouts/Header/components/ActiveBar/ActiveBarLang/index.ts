export { default } from "./ActiveBarLang";
