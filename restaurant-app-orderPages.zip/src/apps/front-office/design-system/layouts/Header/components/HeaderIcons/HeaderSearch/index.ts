export { default } from "./HeaderSearch";
