// import placeholder from "assets/images/placeholder.jpg";
// import placeholderDark from "assets/images/placeholder-dark.png";

export const defaultAvatar = () => "https://via.placeholder.com/150";
