import "./design-system";
import "./utils/locales";
