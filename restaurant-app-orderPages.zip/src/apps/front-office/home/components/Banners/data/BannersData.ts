import img1 from "shared/assets/images/Banners/pexels-photo-11519122.jpg";
import img2 from "shared/assets/images/Banners/pexels-photo-11532336.jpg";
import img3 from "shared/assets/images/Banners/pexels-photo-11568775.jpg";
export const bannerData = [
  {
    id: 1,
    title:
      "Iced coffee is a type of coffee beverage served chilled, brewed variously",
    img: img1,
  },
  {
    id: 2,
    title: "Ricotta, sun dried tomatoes, garlic, mozzarella cheese",
    img: img2,
  },
  {
    id: 3,
    title: "Crispy bacon, tasty ham, pineapple, onion and stretchy mozzarella",
    img: img3,
  },
];
