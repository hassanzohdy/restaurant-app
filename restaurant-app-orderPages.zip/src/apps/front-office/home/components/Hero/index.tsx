export { default } from "./Hero";
