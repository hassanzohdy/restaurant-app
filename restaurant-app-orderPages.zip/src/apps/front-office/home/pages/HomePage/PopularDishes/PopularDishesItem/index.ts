export { default } from "./PopularDishesItem";
