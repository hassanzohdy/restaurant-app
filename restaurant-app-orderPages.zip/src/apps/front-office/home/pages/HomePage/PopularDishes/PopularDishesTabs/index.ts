export { default } from "./PopularDishesTabs";
