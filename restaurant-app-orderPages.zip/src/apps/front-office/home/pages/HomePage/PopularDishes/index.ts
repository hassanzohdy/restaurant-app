export { default } from "./PopularDishes";
