export { default } from "./AboutUsChefsItem";
