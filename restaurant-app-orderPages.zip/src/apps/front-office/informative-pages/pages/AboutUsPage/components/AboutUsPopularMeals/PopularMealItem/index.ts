export { default } from "./PopularMealItem";
