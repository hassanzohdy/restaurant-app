export { default } from "./TermsAndConditionsPage";
