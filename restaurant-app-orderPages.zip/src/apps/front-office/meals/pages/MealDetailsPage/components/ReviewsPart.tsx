// type Props = {
//   reviews?: ReviewType[];
// };

const ReviewsPart = () => {
  return <section>ReviewsSection</section>;
};

export default ReviewsPart;
