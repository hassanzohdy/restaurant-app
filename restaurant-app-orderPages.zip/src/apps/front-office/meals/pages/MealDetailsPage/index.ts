export { default } from "./MealDetailsPage";
