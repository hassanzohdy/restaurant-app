import { setApps } from "@mongez/react-router";
import frontOfficeApp from "apps/front-office/front-office-modules.json";

setApps([frontOfficeApp] as any[]);
